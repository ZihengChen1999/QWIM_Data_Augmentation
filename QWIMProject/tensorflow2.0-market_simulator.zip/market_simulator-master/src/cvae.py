import numpy as np
import matplotlib.pyplot as plt
from sklearn import utils
from tqdm.auto import tqdm
import tensorflow as tf
from IPython import display

import glob
import imageio
import matplotlib.pyplot as plt
import numpy as np
import PIL
import tensorflow as tf
import keras
import time
from keras.layers.merge import concatenate as concat
from keras import backend as K
from keras.layers import LeakyReLU
from keras.optimizers import Adam



lrelu = lambda x: tf.keras.activations.relu(x, alpha=0.02)

class KLDivergenceLayer(keras.layers.Layer):

    """ Identity transform layer that adds KL divergence
    to the final model loss.
    """

    def __init__(self, *args, **kwargs):
        self.is_placeholder = True
        super(KLDivergenceLayer, self).__init__(*args, **kwargs)

    def call(self, inputs):

        mu, log_var = inputs

        kl_batch = - .5 * K.sum(1 + log_var -
                                K.square(mu) -
                                K.exp(log_var), axis=-1)

        self.add_loss(K.mean(kl_batch), inputs=inputs)

        return inputs

class CVAE(keras.Model):
    """Convolutional variational autoencoder."""

    def __init__(self, n_latent=8, alpha=0.1):
        super(CVAE, self).__init__()
        self.n_latent = n_latent
        self.encoder_dim = 50
        self.decoder_dim = 50
        self.alpha = alpha
        self.m = 50
    
    def vae_loss(self, y_true, y_pred):
        """ Calculate loss = reconstruction loss + KL loss for each data in minibatch """
        # E[log P(X|z,y)]
        recon = K.sum(K.binary_crossentropy(y_pred, y_true), axis=1)
        # D_KL(Q(z|X,y) || P(z|X)); calculate in closed form as both dist. are Gaussian
        kl = 0.5 * K.sum(K.exp(self.l_sigma) + K.square(self.mu) - 1. - self.l_sigma, axis=1)

        return recon + kl
    
    def loss(self, y_true, y_pred, alpha=0.1):
        #print('y_true', y_true)
        decoded_loss = tf.reduce_sum(tf.math.squared_difference(y_true, y_pred), 1)
        latent_loss = -0.5 * tf.reduce_sum(1. + self.l_sigma - tf.math.square(self.mu) - tf.math.exp(self.l_sigma), 1)
        #recon_loss = K.sum(K.binary_crossentropy(y_true, y_pred, from_logits=True), axis=-1)
        #return (1-self.alpha)*tf.reduce_mean((1 - self.alpha) * decoded_loss + self.alpha * latent_loss) + self.alpha*recon_loss
        return tf.reduce_mean((1 - self.alpha) * decoded_loss + self.alpha * latent_loss) 

    def KL_loss(self, y_true, y_pred):
        return(0.5 * K.sum(K.exp(self.l_sigma) + K.square(self.mu) - 1. - self.l_sigma, axis=1))

    def recon_loss(self, y_true, y_pred):
        return K.sum(K.binary_crossentropy(y_true, y_pred, from_logits =True), axis=-1)
    
    def sample_z(self, args):
        m = 50
        mu, logvar = args
        eps = K.random_normal(shape=(m, self.n_latent))
        #eps = K.random_normal(shape=(tf.stack([tf.shape(self.X)[0], self.n_latent])), mean=0., stddev=1.)
        return mu + K.exp(logvar / 2) * eps

    
    def train(self, data, data_cond, n_epochs=10000, learning_rate=0.005,
              show_progress=False):

        cutoff_data = data.shape[0] % self.m 
        print('cutoff_data', cutoff_data)
        if cutoff_data != 0:
            data = data[:-cutoff_data]
            data_cond = data_cond[:-cutoff_data]
        print(data)
        #print('data length', data.shape[0])
        data = utils.as_float_array(data)
        data_cond = utils.as_float_array(data_cond)
        
        #print('data', data)
        
        if len(data_cond.shape) == 1:
            data_cond = data_cond.reshape(-1, 1)
            
        #print('train', [data, data_cond])     
        #print('data_cond', data_cond)
        #print('data', data)
        input_dim = data.shape[1]
        self.n = data.shape[0]
        dim_cond = data_cond.shape[1]
        n_z = self.n_latent
        n_y = dim_cond
        n_x = input_dim
        self.n_y = n_y
        self.n_x = n_x
        m = self.m
        
        ## Explicitely define shape for the encoder
        #X = tf.keras.layers.Input(shape=(n_x,))
        X = keras.layers.Input(shape=(n_x,))
        #self.X = X
        label = keras.layers.Input(shape=(n_y,))

        ## Concatenate the input and the label for the CVAE
        inputs = concat([X, label])
   
        #self.sampled, mn, sd = self.encoder(data, self.cond, input_dim=input_dim)
        #self.dec = outputs
        
        #encoder_o = keras.layers.Flatten()(inputs)
        encoder_h = keras.layers.Dense(self.encoder_dim, activation=LeakyReLU(alpha=0.3))(inputs)
        self.mu = keras.layers.Dense(n_z, activation=LeakyReLU(alpha=0.3))(encoder_h)
        self.l_sigma = keras.layers.Dense(n_z, activation=LeakyReLU(alpha=0.3))(encoder_h)
        #self.mu, self.l_sigma = KLDivergenceLayer()([self.mu, self.l_sigma])
        z = keras.layers.Lambda(self.sample_z, output_shape = (n_z, ))([self.mu, self.l_sigma])
        
        # Sampling latent space
        decoder_hidden = keras.layers.Dense(self.decoder_dim, activation=LeakyReLU(alpha=0.3))
        decoder_out = keras.layers.Dense(n_x, activation='sigmoid')
        
        zc = concat([z, label], axis=1)
        h_p = decoder_hidden(zc)
        outputs = decoder_out(h_p)
            
        self.cvae = keras.models.Model([X, label], outputs)    
        self.encoder = keras.models.Model([X, label], self.mu)
        
        d_in = keras.layers.Input(shape=(n_z+n_y,))
        d_h = decoder_hidden(d_in)
        d_out = decoder_out(d_h)
        self.decoder = keras.models.Model(d_in, d_out)
        
        #d_h = decoder_hidden(self.zc)
        #self.outputs = decoder_out(d_h)
        #decoder = keras.models.Model(self.zc, self.outputs)
        
        
        #outputs = decoder(encoder(inputs))
        
        
        #self.cvae = keras.models.Model(inputs, outputs)
        #self.encoder = keras.models.Model([X, label], self.mu)
      
    
        #self.cvae.compile(optimizer=Adam(learning_rate), loss=self.vae_loss, metrics = [self.KL_loss, self.recon_loss])
        self.cvae.compile(optimizer=Adam(learning_rate), loss=self.loss)
        #self.cvae.summary()
        
        #self.cvae.compile(optimizer=Adam(learning_rate), loss=self.vae_loss, metrics = [self.KL_loss, self.recon_loss])
       

        
        # compile and fit
        #n_epoch = 50
        data = data.reshape(-1, n_x)
        data_cond = data_cond.reshape(-1, n_y)
        cvae_hist = self.cvae.fit([data, data_cond], data, verbose = 1, batch_size=m, epochs=n_epochs)
        #self.cvae_hist = cvae.fit([X_train, y_train], X_train, batch_size=m, epochs=n_epochs,
        #    callbacks = [EarlyStopping(patience = 5)])
        #self.decoder.summary()
    
    @tf.function
    def sample(self, n_samples=0, eps=None):
        if eps is None:
            eps = tf.random.normal(shape=(n_samples, self.latent_dim))
        return self.decode(eps, apply_sigmoid=False)
    
    def reparameterize(self, mean, logvar):
        eps = tf.random.normal(shape=mean.shape)
        return eps * tf.exp(logvar * .5) + mean
    
    def generate(self, cond, n_samples=None, eps=None):
        #mean, logvar = self.encoder_h.predict(cond)
        #z = model.reparameterize(mean, logvar)
        #predictions = model.sample(z)
        if n_samples is not None:
            #randoms = np.random.normal(0, 1, size=(n_samples, self.n_latent))
            cond = [list(cond)] * n_samples
        else:
            #randoms = np.random.normal(0, 1, size=(1, self.n_latent))
            cond = [list(cond)]
            n_samples = 1
        #cond = np.array(cond).reshape(-1, 1)
        #print('cond', cond)
        if eps is None:
            eps = tf.random.normal(shape=(n_samples, self.n_latent)).numpy()
        #print('eps', eps)
        return self.decode(eps, cond)
    
    def decode(self, z, cond, apply_sigmoid=False):
        #self.decoder.summary()
        logits = self.decoder.predict(np.concatenate([z, cond], axis=1))
        if apply_sigmoid:
            probs = tf.sigmoid(logits)
            return probs
        return logits
        
    def test(self, z, cond):
        mean = self.encoder.predict([z, cond])
        var = self.encoder.predict([z, cond])
        eps = K.random_normal(shape=(K.shape(z)[0], self.n_latent), mean=0., stddev=1.)
        z_new = mean
        return self.decoder.predict(np.concatenate([z_new, cond], axis=1))
    

